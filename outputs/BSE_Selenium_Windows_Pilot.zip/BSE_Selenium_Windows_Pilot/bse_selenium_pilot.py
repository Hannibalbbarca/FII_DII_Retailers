"""Test BSE and discover downloadable Excel exports using Selenium.

Only official BSE HTTPS sources are permitted. Browser security and TLS
verification remain enabled. Stops on denial/challenge pages; does not use
stealth drivers, CAPTCHA solvers, guessed API routes or alternate data sources.
This pilot does not yet implement historical quarter selection.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

from bse_export_common import DEFAULT_URL, official_url, browser_proxy, blocked_page, excel_kind


def find_browser(explicit=None):
    if explicit:
        if not Path(explicit).is_file():
            raise ValueError('The supplied Chrome/Chromium path does not exist')
        return str(Path(explicit).resolve())
    candidates = [shutil.which(name) for name in ('chrome', 'chromium', 'chromium-browser')]
    for variable in ('LOCALAPPDATA', 'PROGRAMFILES', 'PROGRAMFILES(X86)', 'ProgramW6432'):
        root = os.environ.get(variable)
        if root:
            candidates.append(str(Path(root) / 'Google/Chrome/Application/chrome.exe'))
    candidates.append('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    for path in candidates:
        if path and Path(path).is_file():
            return str(Path(path).resolve())
    raise ValueError('Install Google Chrome, or provide its executable path with --browser')


def site_structure(html):
    """Capture public controls, never cookies or hidden form values."""
    soup = BeautifulSoup(html, 'html.parser')
    return {
        'selects': [{'id': s.get('id'), 'name': s.get('name'),
                     'options': [{'text': o.get_text(' ', strip=True), 'value': o.get('value')}
                                 for o in s.find_all('option')]}
                    for s in soup.find_all('select')],
        'export_controls': [{'id': node.get('id'), 'tag': node.name,
                             'label': node.get_text(' ', strip=True)[:200]}
                            for node in soup.find_all(['a', 'button'])
                            if re.search(r'excel|export|download', node.get_text(' ', strip=True), re.I)],
        'shareholding_text_observed': bool(re.search(r'share\s*holding', soup.get_text(' ', strip=True), re.I))}


def download(session, url, folder):
    requested = url
    for _ in range(6):
        if not official_url(url):
            raise ValueError('Download/redirect leaves official BSE HTTPS hosts')
        response = session.get(url, timeout=(15, 30), allow_redirects=False)
        if response.is_redirect:
            url = urljoin(url, response.headers['Location'])
            continue
        if response.status_code != 200:
            raise ValueError(f'Download returned HTTP {response.status_code}')
        content = response.content
        kind = excel_kind(content)
        if kind is None:
            raise ValueError('Response is not an XLSX/XLS/HTML-table export')
        if len(content) > 32 * 1024 * 1024:
            raise ValueError('Export exceeds the pilot 32 MiB size limit')
        sha = hashlib.sha256(content).hexdigest()
        path = folder / f'{sha}.{kind}'
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() != sha:
            raise ValueError('Existing download failed integrity check')
        path.write_bytes(content)
        return {'requested_url': requested, 'resolved_url': response.url,
                'retrieved_at_utc': datetime.now(timezone.utc).isoformat(),
                'path': str(path.resolve()), 'sha256': sha, 'bytes': len(content),
                'status': 'candidate_export_saved_requires_report_review'}
    raise ValueError('Too many redirects')


def document_status(driver, page_url):
    """Read browser-observed document status; never infer HTTP from titles."""
    status = None
    for entry in driver.get_log('performance'):
        message = json.loads(entry['message'])['message']
        if message.get('method') == 'Network.responseReceived':
            params = message['params']
            response = params['response']
            if params.get('type') == 'Document' and response.get('url') == page_url:
                status = int(response['status'])
    return status


def run(args):
    args.output.mkdir(parents=True, exist_ok=True)
    result = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'requested_url': args.url, 'http_status': None, 'status': 'unrun',
              'phase': 'configuration', 'exports': [], 'export_errors': [],
              'source_policy': 'BSE India only', 'historical_collection_complete': False,
              'report_formats_compared': False}
    driver = None
    stop_file = args.output / 'STOP'
    def stopped():
        if stop_file.exists():
            result['status'] = 'stopped_by_user'
            return True
        return False
    try:
        if not official_url(args.url):
            raise ValueError('Start URL must be an official BSE HTTPS URL')
        options = Options()
        options.binary_location = find_browser(args.browser)
        options.page_load_strategy = 'eager'
        if not args.headed:
            options.add_argument('--headless=new')
        options.add_argument('--disable-dev-shm-usage')
        options.set_capability('goog:loggingPrefs', {'performance': 'ALL'})
        options.set_capability('acceptInsecureCerts', False)
        proxy = browser_proxy()
        if proxy:
            if proxy.get('username'):
                raise ValueError('Authenticated proxy needs supported browser configuration')
            options.add_argument('--proxy-server=' + proxy['server'])
        # Selenium's own localhost driver connection must not use the external
        # web proxy. Chrome itself still uses the configured web proxy above.
        options.ignore_local_proxy_environment_variables()
        os.environ.setdefault('SE_CACHE_PATH', str((args.output / '.driver-cache').resolve()))
        os.environ.setdefault('SE_TIMEOUT', '30')
        result['phase'] = 'browser_startup'
        if stopped():
            return result
        service = Service(executable_path=args.driver) if args.driver else Service()
        driver = webdriver.Chrome(service=service, options=options)
        if stopped():
            return result
        result['browser_version'] = driver.capabilities.get('browserVersion')
        result['phase'] = 'navigation'
        driver.set_page_load_timeout(25)
        driver.set_script_timeout(10)
        timed_out = False
        try:
            driver.get(args.url)
        except TimeoutException:
            timed_out = True
        if stopped():
            return result
        result['resolved_url'] = driver.current_url
        result['page_title'] = driver.title
        result['http_status'] = document_status(driver, driver.current_url)
        html = driver.page_source
        (args.output / 'page_snapshot.html').write_text(html)
        (args.output / 'site_structure.json').write_text(json.dumps(site_structure(html), indent=2) + '\n')
        denied = blocked_page(result['http_status'], html)
        if denied:
            result.update(status='source_access_denied', detail=denied)
            return result
        if timed_out:
            result['status'] = 'navigation_timeout'
            return result
        if not official_url(driver.current_url):
            result['status'] = 'unexpected_navigation'
            return result
        if result['http_status'] != 200:
            result['status'] = ('page_http_status_unknown' if result['http_status'] is None
                                else 'unexpected_http_status')
            return result
        time.sleep(3)
        if stopped():
            return result
        html = driver.page_source
        (args.output / 'page_snapshot.html').write_text(html)
        (args.output / 'site_structure.json').write_text(json.dumps(site_structure(html), indent=2) + '\n')
        denied = blocked_page(result['http_status'], html)
        if denied:
            result.update(status='source_access_denied', detail=denied)
            return result
        soup = BeautifulSoup(html, 'html.parser')
        links = []
        for anchor in soup.find_all('a', href=True):
            url = urljoin(driver.current_url, anchor['href'])
            label = anchor.get_text(' ', strip=True)
            if official_url(url) and (re.search(r'\.xlsx?(?:$|[?#])', url, re.I)
                                      or re.search(r'\bexcel\b', label, re.I)):
                if url not in links:
                    links.append(url)
        result['discovered_export_links'] = links
        if getattr(args, 'check_only', False):
            result['status'] = 'page_loaded_access_only'
            return result
        result['phase'] = 'download'
        with requests.Session() as session:
            session.headers['User-Agent'] = driver.execute_script('return navigator.userAgent')
            session.headers['Referer'] = driver.current_url
            for cookie in driver.get_cookies():
                session.cookies.set(cookie['name'], cookie['value'],
                                    domain=cookie['domain'], path=cookie.get('path', '/'),
                                    secure=cookie.get('secure', False))
            for url in links[:args.max_exports]:
                if stopped():
                    return result
                try:
                    result['exports'].append(download(session, url, args.output))
                except Exception as exc:
                    result['export_errors'].append({'url': url, 'error_type': type(exc).__name__,
                        'detail': str(exc) if isinstance(exc, ValueError) else None})
                    if isinstance(exc, ValueError) and str(exc) in (
                            'Download returned HTTP 401', 'Download returned HTTP 403',
                            'Download returned HTTP 429'):
                        result['download_access_denied'] = True
                        break
                time.sleep(1)
        result['status'] = ('candidate_exports_saved' if result['exports']
                            else 'page_loaded_no_downloadable_excel_links')
        return result
    except Exception as exc:
        result.update(status='browser_error', error_type=type(exc).__name__)
        if isinstance(exc, ValueError):
            result['detail'] = str(exc)
        return result
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                result['browser_shutdown_error'] = True
        result['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        (args.output / 'run.json').write_text(json.dumps(result, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default=DEFAULT_URL)
    parser.add_argument('--browser', help='Chrome/Chromium executable; detected automatically if omitted')
    parser.add_argument('--driver', help='Optional existing compatible chromedriver path')
    parser.add_argument('--headed', action='store_true', help='Show browser on a desktop')
    parser.add_argument('--check-only', action='store_true', help='Check BSE access without downloading exports')
    parser.add_argument('--max-exports', type=int, default=10)
    parser.add_argument('--output', type=Path, default=Path('outputs/bse_selenium_pilot'))
    args = parser.parse_args()
    if not 1 <= args.max_exports <= 25:
        parser.error('--max-exports must be between 1 and 25')
    result = run(args)
    print(json.dumps({'status': result['status'], 'phase': result['phase'],
                      'http_status': result['http_status'], 'exports_saved': len(result['exports']),
                      'report': str(args.output / 'run.json')}))
    if result['status'] not in ('candidate_exports_saved', 'page_loaded_access_only'):
        raise SystemExit(2)


if __name__ == '__main__':
    main()

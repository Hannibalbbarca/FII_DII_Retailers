"""Background worker; always leave a result even if dependencies are missing."""
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--headed', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    # Both the repository layout and the flat distributable are supported.
    root = Path(__file__).resolve().parent
    if not (root / 'bse_selenium_pilot.py').exists():
        sys.path.insert(0, str(root.parent / 'scripts'))
    try:
        from bse_selenium_pilot import DEFAULT_URL, run
        result = run(SimpleNamespace(output=args.output, url=DEFAULT_URL,
                      browser=None, driver=None, headed=args.headed,
                      max_exports=10, check_only=True))
        print(json.dumps({'status': result['status'], 'http_status': result['http_status']}))
        return 0 if result['status'] == 'page_loaded_access_only' else 2
    except Exception as exc:
        result = {'status': 'worker_error', 'error_type': type(exc).__name__,
                  'finished_at_utc': datetime.now(timezone.utc).isoformat()}
        (args.output / 'run.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())

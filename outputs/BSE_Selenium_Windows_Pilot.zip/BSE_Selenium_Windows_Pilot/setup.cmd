@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
    if errorlevel 1 goto python_needed
    py -3 -m venv .venv
) else (
    where python >nul 2>nul
    if errorlevel 1 goto python_needed
    python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
    if errorlevel 1 goto python_needed
    python -m venv .venv
)
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import selenium, requests, bs4"
if errorlevel 1 goto failed
echo Setup finished. Make sure Google Chrome is installed, then double-click run_background.cmd.
pause
exit /b 0
:python_needed
echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
echo Enable the Python launcher or Add Python to PATH during installation, then run setup.cmd again.
pause
exit /b 1
:failed
echo Setup failed. Please copy the error text above. Do not run the pilot until setup succeeds.
pause
exit /b 1

@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" exit /b 1
".venv\Scripts\python.exe" launch_local_pilot.py --status
set "pilot_exit=%errorlevel%"
pause
exit /b %pilot_exit%

@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run setup.cmd first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" launch_local_pilot.py
set "pilot_exit=%errorlevel%"
pause
exit /b %pilot_exit%

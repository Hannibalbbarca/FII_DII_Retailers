"""Shared BSE-only validation; no browser automation dependency."""
import io
import os
import re
import zipfile
from urllib.parse import urlsplit, urlunsplit, unquote

from bs4 import BeautifulSoup

DEFAULT_URL = ('https://www.bseindia.com/stock-share-price/'
               'reliance-industries-ltd/reliance/500325/shareholding-pattern/')


def official_url(url):
    try:
        parsed = urlsplit(url)
        host = (parsed.hostname or '').lower()
        return (parsed.scheme == 'https' and not parsed.username and not parsed.password
                and parsed.port in (None, 443)
                and (host == 'bseindia.com' or host.endswith('.bseindia.com')))
    except ValueError:
        return False


def browser_proxy():
    value = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
    if not value:
        return None
    parsed = urlsplit(value)
    if not parsed.hostname:
        raise ValueError('Configured proxy URL has no hostname')
    host = parsed.hostname
    if ':' in host:
        host = f'[{host}]'
    proxy = {'server': urlunsplit((parsed.scheme, host +
             (f':{parsed.port}' if parsed.port else ''), '', '', ''))}
    if parsed.username:
        proxy['username'] = unquote(parsed.username)
        proxy['password'] = unquote(parsed.password or '')
    return proxy


def blocked_page(status, html):
    soup = BeautifulSoup(html, 'html.parser')
    title = soup.title.get_text(' ', strip=True).lower() if soup.title else ''
    heading = ' '.join(h.get_text(' ', strip=True).lower()
                       for h in soup.find_all(['h1', 'h2']))
    if status in (401, 403, 429):
        return f'HTTP {status}'
    if any(word in title + ' ' + heading for word in
           ('access denied', 'captcha', 'verify you are human', 'just a moment')):
        return 'Access-denied or challenge page'
    return None


def excel_kind(content):
    if content.startswith(b'PK\x03\x04'):
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                if {'[Content_Types].xml', 'xl/workbook.xml'} <= set(archive.namelist()):
                    return 'xlsx'
        except zipfile.BadZipFile:
            pass
        return None
    if content.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'):
        return 'xls'
    if re.search(br'<(?:html|table)\b', content[:8192], re.I):
        soup = BeautifulSoup(content, 'html.parser')
        if not blocked_page(200, str(soup)) and soup.find('table'):
            return 'html'
    return None

BSE SELENIUM - WINDOWS BACKGROUND ACCESS PILOT

This first run checks whether BSE accepts Selenium on your computer. It does
NOT yet download the complete 2016-onward history. Cloud Selenium reached BSE
but got HTTP 403. Local access has not been verified. BSE India is the only data
source; no company investor-relations websites are used.

1. Extract the ZIP into a normal writable folder. Do not run it inside the ZIP.
2. Install Google Chrome and Python 3.10 or newer if needed. Python:
   https://www.python.org/downloads/windows/
   Enable the Python launcher or Add Python to PATH during installation.
3. Double-click setup.cmd once. It creates a private Python environment and
   installs the three pinned dependencies. It does not need administrator
   access or change PowerShell execution policy. Stop if installation fails.
4. Double-click run_background.cmd. Read the result-folder path, then close
   this launcher window if you wish. The worker continues in the background.
5. Double-click status.cmd to check the result. A normal check should finish
   in roughly a minute, but first-time driver installation can take longer.
6. Upload run.json and site_structure.json from the latest results folder to
   this chat. If setup or startup fails, send its displayed error/run.json.

Keep your computer awake and online. You can continue working: the default
browser is headless and uses ChromeDriver's separate temporary browser profile.
No mouse/keyboard automation, personal browser profile, or parallel browser
farm is used. Normal CPU, memory and network usage still applies.

Stop: double-click stop.cmd. It requests cooperative shutdown; the worker
closes its own browser after the current navigation/request returns. It does
not force-kill Chrome or close your personal browser. Do not launch another
pilot until status.cmd shows the previous one has completed.

Result meanings:
- page_loaded_access_only: BSE's page loaded. This does not prove the report
  exports or historical quarter selectors work; we must inspect those next.
- source_access_denied: BSE refused access. Do not keep retrying unchanged or
  attempt to bypass CAPTCHA/access controls.
- browser_error: inspect error_type/detail. Check Chrome installation/network.
- stopped_by_user: the worker honored your stop request.

The script preserves HTTPS verification and browser sandboxing. Selenium
Manager may download a compatible ChromeDriver from the official Chrome for
Testing distribution; those are software dependencies, not report data sources.

Do not upload .venv, .driver-cache, browser profiles, cookies or credentials.
page_snapshot.html is local diagnostic data; do not share it without checking
it for sensitive content. The two requested JSON files contain only the public
page structure and access-result metadata, not browser cookies.

Windows .cmd execution cannot be verified on this Linux cloud host. Python
logic and package contents are tested here; actual Windows/BSE operation still
requires your local run. No recurring service or scheduled task is installed.

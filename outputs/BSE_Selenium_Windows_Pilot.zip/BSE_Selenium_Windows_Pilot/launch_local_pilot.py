"""Launch one isolated access-check worker, or request its cooperative stop."""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def active_run(base):
    active = base / 'active.json'
    if not active.exists():
        return None
    record = json.loads(active.read_text())
    folder = Path(record['output']).resolve()
    if folder.parent != base.resolve():
        raise ValueError('Active-run folder is outside the results directory')
    return dict(record, output=folder)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stop', action='store_true')
    parser.add_argument('--status', action='store_true')
    parser.add_argument('--headed', action='store_true', help='Optional visible browser, not the default')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    base = root / 'results'
    base.mkdir(exist_ok=True)
    previous = active_run(base)
    if args.stop or args.status:
        if not previous:
            print('No pilot has been launched.')
            return
        report = previous['output'] / 'run.json'
        if report.exists():
            print(json.dumps(json.loads(report.read_text()), indent=2))
        elif args.stop:
            (previous['output'] / 'STOP').touch()
            print('Stop requested. The worker will close its browser after the current operation returns.')
        else:
            print(f'Pilot is running. Results folder: {previous["output"]}')
        return
    if previous and not (previous['output'] / 'run.json').exists():
        raise SystemExit('A pilot is already running. Use stop.cmd or status.cmd; do not start another browser.')
    # Remove only our completed launch bookkeeping, never report files.
    active = base / 'active.json'
    if previous:
        active.unlink()
    now = datetime.now(timezone.utc)
    folder = base / (now.strftime('%Y%m%d_%H%M%S') + '_' + uuid4().hex[:6])
    folder.mkdir()
    worker = root / 'run_local_worker.py'
    command = [sys.executable, '-u', str(worker), '--output', str(folder)]
    if args.headed:
        command.append('--headed')
    record = {'output': str(folder.resolve()), 'started_at_utc': now.isoformat(),
              'mode': 'BSE-only access check; no historical bulk collection'}
    # Exclusive creation prevents concurrent launchers from starting two workers.
    with active.open('x') as launch_record:
        launch_record.write(json.dumps(record, indent=2))
        launch_record.flush()
        try:
            with (folder / 'stdout.log').open('w') as stdout, (folder / 'stderr.log').open('w') as stderr:
                flags = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
                process = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr,
                                           creationflags=flags, start_new_session=sys.platform != 'win32')
            record['worker_pid'] = process.pid
        except Exception as exc:
            (folder / 'run.json').write_text(json.dumps({
                'status': 'launch_error', 'error_type': type(exc).__name__,
                'finished_at_utc': datetime.now(timezone.utc).isoformat()}, indent=2))
            raise
    active.write_text(json.dumps(record, indent=2) + '\n')
    print('Background access check started. You can keep using your computer.')
    print(f'Results: {folder}')
    print('Use status.cmd to check completion or stop.cmd to request a stop.')


if __name__ == '__main__':
    main()
